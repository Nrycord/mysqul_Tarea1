//Programa creado por: Carlos Enrique Cordero Linares. CL18030. Programacion 1

#include <iostream> //ENTRADA Y SALIDAD DE DATOS
#include <winsock2.h>//PERMITE UTILIZAR EL MYSQL
#include <mysql.h>//SE ENCARGA DEL MANEJO DE BASES DE DATOS
#include <mysqld_error.h>//PERMITE LA GENERACION DE NOTIFICACIONES DE ERRORES EN EL CODIGO
using namespace std;

int menuMost();
int cl(int);
void mostCli(bool);
void instCli();
void mostCot(bool);
void instCot();
void mostProd(bool);
void instProd();
void mostVent(bool);
void instVent();

//Variables globales para facilidad del codigo
MYSQL *conn;
MYSQL  mysql;
MYSQL_RES *res;
MYSQL_ROW row;
//Variables globales para facilidad del codigo
    
int main()
{  
	bool v = false;//permite evadir un ciclo al agregar datos a la base de datos
	int menu; //seleccionara que accion toma
    int conti; //permite la repeticion del programa
    mysql_init(&mysql); //inicia mysql
    conn=mysql_real_connect(&mysql,"localhost","root","","tarea1",0,0,0);
    
    if(conn==NULL)//si el servidor no inicia, entonces muestra porque
    { 
		cout<<mysql_error(&mysql)<<endl;
        system("pause");
     /// return 1;
        
    }
    
    
   do{
	 
    menu = menuMost();//menu toma el valor de la funcion que el usuario selecciona
    
    switch(menu) //decide que hacer y que funcion efectuar
    {
    	case 1:
    		mostCli(v);
    		break;
    	case 2:
    		mostCot(v);
    		break;
    	case 3:
    		mostProd(v);
    		break;
    	case 4:
    		mostVent(v);
			break;
		case 5:
			conti = 2;
    		break;
	}
	}while(conti != 2);
}


int menuMost()//muestra el menu y sus opciones
{
	int menu;
    bool continuar = true;
    cout << "\n\n\n\n\n________________________________________________________________________________________________________________________" << endl;
    cout << "                                                   Bienvenido      "<< endl;
    cout << "                                          __________________________ "<< endl;
    cout << "------------------------------------------------------------------------------------------------------------------------" << endl;
    cin.get();
    system("cls");

    do{

    cout << "Que tramite desearia realizar?" << endl;
    cout << "------------------------------------------------------------------------------------------------------------------------" << endl;
    cout << "1:Abrir lista de clientes." << endl << "2:Abrir lista de cotizaciones." << endl << "3:Abrir lista de productos." << endl;
    cout<< "4:Abrir lista de ventas." << endl << "5:Salir." << endl << "=>";
    cin >> menu;
    menu = cl(menu);
    }while(menu < 0 || menu > 5);
    return menu;//retorna el valor de lo que el usuario desea hacer
}


void mostCli(bool v)//muestra la lista de clientes en la base de datos
{
	
	cout << "\t\t TABLA DE CLIENTES:" << endl;
	mysql_query(conn,"select * from clientes");//seleccionamos a que tabla agregaremos los datos
    res=mysql_store_result(conn);
    cout << "codcliente nombre apellido tel" << endl;
    while((row=mysql_fetch_row(res))!=NULL) //mientras el campo no este vacio
    {
    	cout << "__________________________________________________" << endl;
        cout << "|" << row[0]<< "|" << "\t";
        cout << "|" << row[1]<< "|" <<"\t";//muestra todas las columnas y las filas de la tabla
        cout << "|" << row[2]<< "|" <<"\t";
        cout << "|" << row[3]<< "|" <<endl;
        cout << "--------------------------------------------------" << endl;
    }

    system("pause");
    
	if(!v)//si no viene de la funcion instVent()
	{
		int agr;
		do{
			cout << "Desea agregar un cliente? (1: Si, 2: No)" << endl;
			cin >> agr;
   			agr = cl(agr);
    	}while(agr < 1 || agr > 2);
    
    	if(agr == 1) //si el cliente si desea agregar un cliente
    	{
    		instCli();
		}
	}
}


void instCli()//agrega un cliente en la base de datos
{
	int qstate;//muestra el estado de la variable q
	string nombre;//cada uno de los  
	string apellido;//campos que queremos
	string tel;//ingresar en la tabla
	
	cout << "Ingrese el nombre del cliente" << endl;
	cin >> nombre;
	cout << "Ingrese el apellido del cliente" << endl;
	cin >> apellido;
	cout << "Ingrese el telefono del cliente" << endl;
	cin >> tel;
	
	//ingresa el valor en la base de datos
	string query = "insert into clientes (nombre, apellido, tel) values ('"+nombre+"', '"+apellido+"','"+tel+"')";
	const char* q = query.c_str();
	
	//muestra que los datos esten correctos
	cout << "El dato a agregar es: " << q << endl;
	qstate = mysql_query(conn,q);
	
	//si no muestra error...
	if(!qstate)
	{
		cout << "Dato ingresado correctamente" << endl;	
	}
	else //de otra forma explica cual es el error
	{
		cout << "Problema al agregar el dato: " << mysql_error(conn) << endl;
	}
	system("pause");
}


void mostCot(bool v)//muestra la lista de cotizaciones de la base de datos 
{
	cout << "\t TABLA DE COTIZACIONES:" << endl;
	mysql_query(conn,"select * from cotizaciones");//seleccionamos a que tabla agregaremos los datos
    res=mysql_store_result(conn);
    
    cout << "codcotiz codprod codclient fecha" << endl;
    while((row=mysql_fetch_row(res))!=NULL)//mientras el campo no este vacio
    {
    	
    	cout << "_____________________________________________" << endl;
        cout << "|" << row[0]<< "|" << "\t";
        cout << "|" << row[1]<< "|" <<"\t";
        cout << "|" << row[2]<< "|" <<"\t";//muestra todas las columnas y las filas de la tabla
        cout << "|" << row[3]<< "|" <<endl;
        cout << "---------------------------------------------" << endl;
    }

    system("pause");
    
    if(!v)//si no viene de la funcion instCot()
    {
    int agr;
	
	do{
	cout << "Desea agregar un a cotizacion? (1: Si, 2: No)" << endl;
	cin >> agr;
    agr = cl(agr);
    }while(agr < 1 || agr > 2);
    
    if(agr == 1)
    {
    	instCot();
	}
	}
}


void instCot()
{
	bool v = true; //si entra a las funciones mostCli() o mostVent() entonces desabilita el ingresar un cliente o una venta en este proceso
	int qstate;
	string codproducto;
	string codcliente;
	
	
	mostProd(v);
	cout << "Ingrese el codigo del producto cotizado: " << endl;
	cin >> codproducto;
	system("cls");
	mostCli(v);
	cout << "Ingrese el codigo del cliente que lo compro: " << endl;
	cin >> codcliente;
	system("cls");
	//asigna el valor a la base de datos
	string query = "insert into cotizaciones (cod_producto, cod_cliente) values ('"+codproducto+"','"+codcliente+"')";
	const char* q = query.c_str();
	//verifica que el valor sea correcto
	cout << "El dato a agregar es: " << q << endl;
	qstate = mysql_query(conn,q);
	
	if(!qstate) //si no da errores...
	{
			cout << "Dato ingresado correctamente" << endl;	
	}
	else //por otro lado si da error, muestra cual es
	{
		cout << "Problema al agregar el dato: " << mysql_error(conn) << endl;
	}
	system("pause");
}

	
void mostProd(bool v)//muestra la lista de productos de la base de datos
{
	cout << "\t\t\tTABLA DE PRODUCTOS:" << endl;
	mysql_query(conn,"select * from productos");//seleccionamos a que tabla agregaremos los datos
    res=mysql_store_result(conn);
    
    cout << "codprod nombre precio exigencias fecha" << endl;
    while((row=mysql_fetch_row(res))!=NULL)//mientras el campo no este vacio
    {
    	
    	cout << "_____________________________________________________________________________" << endl;
        cout << "|" << row[0]<< "|" << "\t";
        cout << "|" << row[1]<< "|" <<"\t";
        cout << "|" << row[2]<< "|" <<"\t";
        cout << "|" << row[3]<< "|" <<"\t";//muestra todas las columnas y las filas de la tabla
        cout << "|" << row[4]<< "|" <<endl;
        cout << "-----------------------------------------------------------------------------" << endl << endl;
    }
    
    system("pause");
    
    if(!v)//si no viene de la funcion instCot()
    {
    int agr;
	
	do{
	cout << "Desea agregar un producto? (1: Si, 2: No)" << endl;
	cin >> agr;
    agr = cl(agr);
    }while(agr < 1 || agr > 2);
    
    if(agr == 1)
    {
    	instProd();
	}
	}
}


void instProd()//inserta un producto en la base de datos
{
	int qstate;//muestra el estado de la variable q
	string nombre;
	string precio;
	string existencias;
	
	cout << "Ingrese el nombre del producto" << endl;
	cin >> nombre;
	cout << "Ingrese el precio del producto" << endl;
	cin >> precio;
	cout << "Ingrese las existencias del producto" << endl;
	cin >> existencias;
	//ingresa el valor en la base de datos
	string query = "insert into productos (nombre, precio, existencias) values ('"+nombre+"', '"+precio+"','"+existencias+"')";
	const char* q = query.c_str();
	//muestra que los datos esten correctos
	cout << "El dato a agregar es: " << q << endl;
	qstate = mysql_query(conn,q);
	//si no muestra error...
	if(!qstate)
	{
			cout << "Dato ingresado correctamente" << endl;	
	}
	else //de otra forma explica cual es el error
	{
		cout << "Problema al agregar el dato: " << mysql_error(conn) << endl;
	}
	system("pause");
}


void mostVent(bool v)//muestra las ventas que estan en la base de datos
{
	cout << "\t\tTABLA DE VENTAS:" << endl;
	mysql_query(conn,"select * from ventas");//seleccionamos a que tabla agregaremos los datos
    res=mysql_store_result(conn);
    
    cout << "codventa codprod cantidad fecha codcliente" << endl;
    while((row=mysql_fetch_row(res))!=NULL)//mientras el campo no este vacio
    {
		cout << "___________________________________________________________" << endl;
        cout << "|" << row[0]<< "|" << "\t";
        cout << "|" << row[1]<< "|" <<"\t";
        cout << "|" << row[2]<< "|" <<"\t";
        cout << "|" << row[3]<< "|" <<"\t";
        cout << "|" << row[4]<< "|" <<endl;//muestra todas las columnas y las filas de la tabla
        cout << "-----------------------------------------------------------" << endl << endl;
        
    }
    system("pause");
    
    if(!v)//si no viene de la funcion instVent()
    {
    	int agr;
	
		do{
		cout << "Desea agregar una venta? (1: Si, 2: No)" << endl;
		cin >> agr;
    	agr = cl(agr);
    	}while(agr < 1 || agr > 2);
    
    	if(agr == 1)
    	{
    		instVent();
		}	
	}
    
	
}


void instVent()//agrega una venta a la base de datos
{
	bool v = true; //si entra a las funciones mostCli() o mostVent() entonces desabilita el ingresar un cliente o una venta en este proceso
	int qstate;
	string codpro;
	string cantidad;
	string codcliente;
	
	mostProd(v);
	cout << "Ingrese el codigo del producto vendido: " << endl;
	cin >> codpro;
	system("cls");
	cout << "Ingrese la cantidad vendida: " << endl;
	cin >> cantidad;
	mostCli(v);
	cout << "Ingrese el codigo del cliente que lo compro: " << endl;
	cin >> codcliente;
	system("cls");
	//asigna el valor a la base de datos
	string query = "insert into ventas (codpro, cantidad, codcliente) values ('"+codpro+"', '"+cantidad+"','"+codcliente+"')";
	const char* q = query.c_str();
	//verifica que el valor sea correcto
	cout << "El dato a agregar es: " << q << endl;
	qstate = mysql_query(conn,q);
	
	if(!qstate) //si no da errores...
	{
			cout << "Dato ingresado correctamente" << endl;	
	}
	else //por otro lado si da error, muestra cual es
	{
		cout << "Problema al agregar el dato: " << mysql_error(conn) << endl;
	}
	system("pause");
}


int cl(int clear) //verifica si un dato erroneo fue ingresado y lo corrige
{
	if (cin.fail()) //si al ingresar los datos causo error entra al ciclo
    	{
			cin.clear(); // limpia la variable
        	cin.ignore(); // borra espacios y caracteres
        	cout << "Ingrese un numero valido." << endl;
        	system("pause"); // pausa el programa hasta que el usuario desee

			clear = -1;
			/*asigna el valor de clear a -1, de esa forma los ciclos se repiten
        			si clear entra al if*/
    	}
    return clear;//retorna la variable ya revisada y/o corregida
}
