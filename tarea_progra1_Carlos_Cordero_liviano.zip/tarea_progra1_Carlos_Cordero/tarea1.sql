-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 18, 2018 at 05:29 AM
-- Server version: 5.7.23
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tarea1`
--

-- --------------------------------------------------------

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
CREATE TABLE IF NOT EXISTS `clientes` (
  `codcliente` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `apellido` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `tel` varchar(8) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`codcliente`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `clientes`
--

INSERT INTO `clientes` (`codcliente`, `nombre`, `apellido`, `tel`) VALUES
(1, 'Charlestone', 'Maximilian', '96430659'),
(2, 'Herberth', 'Romanic', '30239657'),
(3, 'Charles', 'Cord', '40434539'),
(4, 'Darwin', 'Maquiavelo', '3959796'),
(5, 'Alexander', 'Dawking', '98923045'),
(6, 'carlos', 'cordero', '23452345'),
(7, 'adriana', 'cordero', '34563456');

-- --------------------------------------------------------

--
-- Table structure for table `cotizaciones`
--

DROP TABLE IF EXISTS `cotizaciones`;
CREATE TABLE IF NOT EXISTS `cotizaciones` (
  `cod_cotizacion` int(11) NOT NULL AUTO_INCREMENT,
  `cod_producto` int(11) NOT NULL,
  `cod_cliente` int(11) NOT NULL,
  `fecha_cotizacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`cod_cotizacion`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `cotizaciones`
--

INSERT INTO `cotizaciones` (`cod_cotizacion`, `cod_producto`, `cod_cliente`, `fecha_cotizacion`) VALUES
(1, 1, 1, '2018-11-17 19:38:03'),
(2, 2, 2, '2018-11-17 20:13:34'),
(3, 3, 6, '2018-11-18 05:06:48');

-- --------------------------------------------------------

--
-- Table structure for table `productos`
--

DROP TABLE IF EXISTS `productos`;
CREATE TABLE IF NOT EXISTS `productos` (
  `codpro` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `precio` float NOT NULL,
  `existencias` int(11) DEFAULT NULL,
  `fechaingreso` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`codpro`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `productos`
--

INSERT INTO `productos` (`codpro`, `nombre`, `precio`, `existencias`, `fechaingreso`) VALUES
(1, 'Napkins', 0.25, 100, '2018-11-17 01:42:08'),
(2, 'Plastic forks', 0.35, 400, '2018-11-17 01:42:08'),
(3, 'Bleach', 1.25, 50, '2018-11-17 01:43:09'),
(4, 'Plastic plates', 0.6, 90, '2018-11-17 01:43:09'),
(5, 'Cheese', 2.5, 20, '2018-11-17 01:44:09'),
(6, 'Fish', 5.43, 400, '2018-11-18 03:01:39'),
(7, 'Carrots', 1.23, 40, '2018-11-18 03:03:38');

-- --------------------------------------------------------

--
-- Table structure for table `ventas`
--

DROP TABLE IF EXISTS `ventas`;
CREATE TABLE IF NOT EXISTS `ventas` (
  `codventa` int(11) NOT NULL AUTO_INCREMENT,
  `codpro` int(8) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `fecha` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `codcliente` int(11) NOT NULL,
  PRIMARY KEY (`codventa`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Dumping data for table `ventas`
--

INSERT INTO `ventas` (`codventa`, `codpro`, `cantidad`, `fecha`, `codcliente`) VALUES
(1, 1, 25, '2018-11-08 08:59:06', 1),
(2, 2, 10, '2018-11-08 08:59:06', 2),
(3, 3, 150, '2018-11-16 20:00:36', 3),
(4, 4, 210, '2018-11-16 20:00:36', 4),
(5, 5, 10, '2018-11-16 20:00:36', 5),
(6, 3, 4, '2018-11-17 21:47:06', 2);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
